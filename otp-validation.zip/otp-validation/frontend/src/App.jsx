import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
// const LoginForm = lazy(() => import("./components/LoginForm"))
import LoginPage from "./components/loginPage";
import OtpPage from "./components/OtpPage";
import WelcomePage from "./components/WelcomePage";
import PrivateRoute from "./PrivateRoute";
// import PrivateRoute from "./components/PrivateRoute";



function App() {
  return (
    <>
      <ToastContainer />
      <Router>
        <Routes>
          <Route path="/" element={<LoginPage/>}></Route> 
          <Route path='/otp-page' element={<OtpPage/>}/>                       
          <Route
            path="/dashboard"
            element={<PrivateRoute Component={WelcomePage} />}
          />         
          <Route />
        </Routes>
      </Router>
    </>
  );
}

export default App;