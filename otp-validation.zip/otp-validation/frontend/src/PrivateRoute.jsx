import React, { useEffect, useState } from 'react'

const PrivateRoute = ({Component}) => {
const [flag,setFlag] = useState(false)
    useEffect(()=>{
        const token = localStorage.getItem('token') 
        if(token){
            setFlag(true)
        }
    },[])                                                                    

     const logout = ()=>{
      localStorage.clear()
      navigate('/')
  }

  setTimeout(() => {
    logout()
  }, 2*60*1000); // auto logout after 2 minutes


  return (
    <>
        {flag  ?  <Component/> : 
        <>
          <h2 className='text-center mt-5'>Unauthorized Access. Please login to continue.</h2>
          <a href="/" style={{display:'flex',justifyContent:'center'}}>Login</a>
        </>}
    </>
  )
}

export default PrivateRoute