import React, { useEffect, useState } from 'react'
import Form from 'react-bootstrap/Form'
import Button from 'react-bootstrap/Button';
import OpenApi from './OpenApi';
import { useNavigate } from 'react-router-dom';
import { useLocation } from "react-router-dom";


const OtpPage = () => {
    const [otp, setOtp] = useState('')
    const [error, setError] = useState('')
    const [userotp,setUserOtp] = useState('')
    const { search } = useLocation();
    const params = new URLSearchParams(search);

    const data = params.get("data");
    const type = params.get("type");
    let navigate = useNavigate()
    useEffect(()=>{
        console.log('data1',data&&data);
        console.log('type1',type&&type);
        if(type==='phone'){
            OpenApi.get(`/sendotp/${data}`)
        .then((res)=>{
            console.log('otp res',res);  
            setOtp(res.data.otp)                 
        }).catch((err)=>{
            console.log('error in sending otp',err);            
        })
        } 
        else if (type==='email')       {
            OpenApi.get(`/send-mail-otp/${data}`)
        .then((res)=>{
            console.log('otp res',res);  
            setOtp(res.data.otp)                     
        }).catch((err)=>{
            console.log('error in sending otp',err);            
        })
        }
        else{
            console.log('Type error');            
        }
    },[])

    useEffect(()=>{        
        otp && setUserOtp(otp)
    })

    const handleSubmit = (e) => {
        e.preventDefault()
        if(!otp){
            setError('Please enter OTP')
        }
        else{
            console.log('lll',otp);
            
            OpenApi.post('/validate-otp',{otp:userotp})
            .then((res)=>{
            navigate('/dashboard')
            console.log('validated',res.data)
            localStorage.setItem('token',res.data.token)
        })
        .catch((err)=>{
            console.log('validation err',err);            
            setError('Incorrect OTP')
        })
        }        
    }

    return (

        <div
            style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                height: "100vh"
            }}
        >
            <div
                style={{
                    width: "300px",
                    border: "1px solid grey"
                }}
            >
                <Form onSubmit={handleSubmit} className="p-4" >
                    <h4 className="mb-3 text-center">Enter OTP</h4>

                    <Form.Group controlId="otpInput">
                        <Form.Label>OTP</Form.Label>

                        <Form.Control
                            type="text"
                            placeholder="Enter 6-digit OTP"
                            value={otp && otp}
                            // onChange={handleChange}
                            minLength={6}
                            maxLength={6}
                            isInvalid={!!error}
                        />

                        <Form.Control.Feedback type="invalid">
                            {error}
                        </Form.Control.Feedback>
                    </Form.Group>

                    <Button type="submit" className="mt-3 w-100">
                        Verify OTP
                    </Button>
                </Form>
            </div>
        </div>
    )
}

export default OtpPage