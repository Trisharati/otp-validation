import axios from "axios";

const OpenApi = axios.create({baseURL:'http://localhost:4000'})

export default OpenApi;