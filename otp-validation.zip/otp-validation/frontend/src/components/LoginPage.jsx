import React, { useState } from "react";
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import OpenApi from "./OpenApi";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";


function LoginPage() {
    const [email, setEmail] = useState("");
    const [phone, setPhone] = useState('')
    const [error, setError] = useState("");

    const navigate = useNavigate()

    const handleChange = (e) => {
        const value = e.target.value;
        console.log('type', e.target.value);
        e.target.type === 'email' ? setEmail(value) && setPhone('') : null;
        e.target.type === 'tel' ? setPhone(value) && setEmail('') : null;
    }

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log('p', phone, email);
        if (!email.trim() && !phone.trim()) {
            alert("Empty field");
            return;
        }
        else {
            const emailRegex = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
            const isValid = emailRegex.test(email);
            
            // console.log(emailRegex.test("john@example.com")); // true

            if (phone && phone.trim().length < 10 || phone && phone.trim().length > 10) {
                alert("Make sure phone number is 10 digits");
                return;
            }
            else if(email && !isValid){
                alert('Invalid email format');
                return
            }
            else{
                setError("");
            let obj = {
                email: email,
                phone: phone
            }
            let data, type
            if (email) {
                data = email
                type = 'email'
            }
            else if (phone) {
                data = phone
                type = 'phone'
            }
            try {

                OpenApi.post('/login', obj)
                    .then((res) => {
                        console.log('res', res);
                        console.log('data', data);
                        console.log('type', type)
                        toast.success("Login successful");
                        navigate(`/otp-page?data=${data}&type=${type && type}`)
                    })
                    .catch((err) => {
                        console.log('err', err);

                    })
            } catch (error) {
                console.log('catch', error);

            }
            }
            
        }
    };

    return (
        <div style={{ width: '400px', margin: "20px auto", border: '1px solid black' }}>

            <h2 style={{ display: 'flex', justifyContent: 'center' }}>Login</h2>
            <Form onSubmit={handleSubmit}>
                <div style={{ margin: '10px' }}>
                    <Form.Group className="mb-3" controlId="formBasicEmail">
                        <Form.Label>Email address</Form.Label>
                        <Form.Control type="email"
                            placeholder="Enter email"
                            value={email ? email : ''}
                            onChange={handleChange} />
                        <Form.Text className="text-muted">
                        </Form.Text>
                    </Form.Group>
                                        
                    <p style={{ display: 'flex', justifyContent: 'center', color: 'grey' }}>or</p>
                    <Form.Group className="mb-3" controlId="formBasicPassword">
                        <Form.Label>Phone</Form.Label>
                        <Form.Control type="tel"
                            placeholder="Enter Phone"
                            value={phone ? phone : ''}
                            onChange={handleChange} />
                    </Form.Group>
                    <Form.Group className="mb-3" controlId="formBasicCheckbox">
                    </Form.Group>
                    <Button variant="success" type="submit" >
                        Submit
                    </Button>
                </div>
            </Form>
        </div>
    );
}

export default LoginPage;
