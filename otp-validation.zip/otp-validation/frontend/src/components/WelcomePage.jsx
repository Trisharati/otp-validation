import React from 'react'
import { Navbar, Nav, Container, Card } from "react-bootstrap";
import { useNavigate } from 'react-router-dom';

const WelcomePage = () => {
let navigate = useNavigate()
  const handleLogout = () => {
    localStorage.clear();
    navigate('/')
  }
  return (
    <>
      {/* Navbar */}
      <Navbar bg="dark" variant="dark" expand="lg">
        <Container>
          <Navbar.Brand href="#">My Dashboard</Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="ms-auto">
                  <Nav.Link onClick={handleLogout}>Logout</Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>

      {/* Dashboard Welcome Section */}
      <Container className="mt-5">
        <Card className="shadow p-4">
          <h2 className="text-center mb-3">Welcome to Your Dashboard 🎉</h2>
          <p className="text-center">
            This is a simple dashboard welcome page.
          </p>
        </Card>
      </Container>
    </>
  )
}

export default WelcomePage




