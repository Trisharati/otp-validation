const { login, sendOTP, validateOTP, sendMailOTP } = require("../Controller/dashboardController");

const router = require("express").Router();


router.post('/login',login)
router.get('/sendotp/:phone',sendOTP)
router.get('/send-mail-otp/:email',sendMailOTP)
router.post('/validate-otp',validateOTP)

module.exports = router