const twilio = require("twilio");
require("dotenv").config();
const nodemailer = require("nodemailer");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const login = async(req,res)=>{
    console.log('body',req.body);
    try {
        res.status(200)
        .json({
        message:'Login successful'
    })    
    } catch (error) {
        res.status(400).json({
            message:'Some error occurred'
        })
    }    
}



const sendOTP = async (req, res) => {
  try {
    // const client = twilio(process.env.TWILIO_SID, process.env.TWILIO_TOKEN);

    const otp = Math.floor(100000 + Math.random() * 900000);
    req.otp = otp;

    const phone = req.params?.phone;
    console.log('phone',phone);

    console.log("otp", otp);

    // const message = await client.messages.create({
    //   body: `Your OTP is ${otp}`,
    //   from: process.env.TWILIO_PHONE,
    //   to: 91+phone
    // });


    return res.status(200).json({ status: 1,otp:otp });
  } catch (err) {
    console.error("otp error", err);
    return res.status(500).json({ status: 0, error: "Failed to send OTP" });
  }
};

const sendMailOTP = async(req,res)=>{
    // console.log('mail',req.params);    
//   const transporter = nodemailer.createTransport({
//     service: "gmail", 
//     auth: {
//       user: "abc@gmail.com",
//       pass: "********", 
//     },
//   });
  
//   const mailOptions = {
//     from: "abc@gmail.com",
//     to: req.params.email,
//     subject: "Login OTP",
//     text: `OTP is : ${req.otp}`,
//   };

  try {
    // const info = await transporter.sendMail(mailOptions);
    // console.log("Email sent: " + info.response);
    const otp = Math.floor(100000 + Math.random() * 900000);
    req.otp = otp;
    console.log('mail otp',otp);
    res.status(200).json({status:1,otp:req.otp})
  } catch (error) {
    console.error("Error sending email:", error);
  }    
}

const validateOTP = async(req,res)=>{
console.log('req otp',req.otp);
console.log('body otp',req.body.otp);
let otp = req.body.otp && req.body.otp
const token = jwt.sign({otp}, process.env.JWT_SECRET_KEY, {
        expiresIn: '1m' // Token expires in 1 min
    });

res.status(200).json({status:1,token:token})
}


module.exports = {login,sendOTP,sendMailOTP,validateOTP}